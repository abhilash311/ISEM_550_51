    $(function() {
	$(document).ready(function() {
    $("#txtDate, #txtDate1").datepicker({
        showOn: 'focus',
        dateFormat: 'mm/dd/yy',
        constrainInput: true
    });
		initializingCarousel();
		});  
	//	var date1 = $( "#txtDate" ).datepicker({ dateFormat: 'dd-mm-yy' });
		//var date2 = $( "#txtDate1").datepicker({ dateFormat: 'dd-mm-yy' });
		

$('.oneway, .RoundTrip').change(function()
{
if($('.oneway').is(':checked'))
{
	$("#txtDate1").attr('disabled','disabled');
}
else{
		$("#txtDate1").removeAttr('disabled');
}

});
						});
function flightDetails()
{
	var d1 = $('#txtDate').val();
	var d2 = $('#txtDate1').val();
	checkvalue = false;
	if($('.oneway').is(':checked'))
	{
		 if(d1 != '')
		 {
			 checkvalue = true;
		 }
	}
	else
	{
		if(d2 != '' && d1 != '')
		{
			checkvalue = true;
		}
	}


	if(checkvalue)
	{

var d1date = d1.substring(3, 5);
var d2date = d2.substring(3, 5);
var d1num = parseInt(d1date);
var d2num = parseInt(d2date);
var d1dec = d1num - 2;
var d1inc = d1num + 2;
var d2dec = d2num - 2;
var d2inc = d2num + 2;
d1old = d1.substring(0, 2)+"-"+d1dec+"-"+d1.substring(6, 10);
d1new = d1.substring(0, 2)+"-"+d1inc+"-"+d1.substring(6, 10);
d2old = d2.substring(0, 2)+"-"+d2dec+"-"+d2.substring(6, 10);
d2new = d2.substring(0, 2)+"-"+d2inc+"-"+d2.substring(6, 10);

$('.date1').html(d1old);
$('.date2').html(d2old);
$('.date3').html(d1);
$('.date4').html(d2);
$('.date5').html(d1new);
$('.date6').html(d2new);
if($('.oneway').is(':checked'))
{
	$('.return').addClass('disp-hidden');
}
else {
	if($('.return').hasClass('disp-hidden'))
	{
		$('.return').removeClass('disp-hidden')
	}
}
var startpt = $('.starting').val();
var dest = $('.destination').val();
$('.From').html(startpt);
$('.To').html(dest);
	$('.detailsContent').removeClass('disp-hidden');
	
	
}	
else{
	
	alert("Please enter all the fields")
}		
}	
function confirmRes()
{
	alert('Your Reservation is Confirmed. Thankyou');
}	
function initializingCarousel()
{
		$('.slider1').mytinycarousel({bullets:true,interval:true,infinite:true});
}
